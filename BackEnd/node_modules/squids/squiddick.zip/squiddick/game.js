
/*
Copyright 2022  Sleepless Software Inc.  All Rights Reserved

See the LICENSE.txt file included with the Squids source code for 
licensing information

*/

// Any fonts that the browser has available to it can be created
let font = load_font( "Arial", 30, "turquoise" );

// Squids creates a global canvas reference
let sw = canvas.width;
let sh = canvas.height;

// This is where I'm going to store the images and sounds that I've loaded
let assets = {};


// Create a Thing object to manage the title/loading screen
title = new Thing();
load_progress = 0;
load_file = "";

// listen for the draw event and do our own custom rendering.
title.listen( "draw", ( mouse_x, mouse_y ) => {
	if( load_progress < 1.0 ) {

		draw_text( "The Chronicles of Squiddick", sw * 0.5, sh * 0.3, font, "center", 1 );
		draw_text( "Loading: "+round(load_progress * 100)+"% "+load_file, sw * 0.5, sh * 0.4, font, "center", 0.5 );

	} else  {

		draw_text( "The Chronicles of Squiddick", sw * 0.5, sh * 0.3, font, "center", 0.5 );
		draw_text( "Click to Start ", sw * 0.5, sh * 0.4, font, "center", 1 );

		draw_text( "WASD to drive submarine. ", sw * 0.5, sh * 0.60, font, "center", 0.5 );
		draw_text( "M to turn off music.", sw * 0.5, sh * 0.65, font, "center", 0.5 );
		draw_text( "Click squid for ink.", sw * 0.5, sh * 0.70, font, "center", 0.5 );
		load_file = "";

	}
} );


// turn on ticking; tick handlers will be called
tick( true );


// Start actually loading the assets
load_assets( [ 
	"blot.png",
	"bubble.svg",
	"fish0-lt.png",
	"fish0-rt.png",
	"fish1-lt.png",
	"fish1-rt.png",
	"squid.png",
	"squid_0.svg",
	"squid_1.svg",
	"squid_2.svg",
	"squid_3.svg",
	"squid_4.svg",
	"sub1.png",
	"sub2.png",
	"tiles.png",
], [
	"underwater.mp3",
	"slurp.mp3",
	"chomp.mp3",
	"sploo.mp3",
	"music.mp3",
], ( progress, file, asset, type ) => {
	// This is called each time a file is loaded

	load_progress = progress;
	load_file = file;
	assets[ file ] = asset;

	log( load_progress+"% "+type+" "+file );
	if( load_progress >= 1.0 ) {
		// the loading is complete
		// listen for a mousedown event
		title.listen( "mousedown", () => {
			// Mouse clicked.
			// Nuke the title object and start the game proper
			title.destroy();	// destroy the title page
			game();				// advance to the game
		} )
	}

}, console.error );


// called after assets are loaded to enter the main game play
function game() {

	// set up my background music
	music = assets["music.mp3"];	// get the sound object
	music.volume( 0.2 );			// reduce the volume
	music.play();					// start it playing
	// detect when bg music is done so i can loop it.
	music.on( "end", () => {
		music.play();
	} );


	// set up my looping, watery background sounds
	water = assets["underwater.mp3"];
	water.volume( 0.3 );
	water.play();
	water.on( "end", () => {
		water.play();
	} );


	// grab some sound effects and prep them
	slurp = assets["slurp.mp3"];
	slurp.volume( 0.5 );

	sploo = assets["sploo.mp3"];
	sploo.volume( 1.0 );

	chomp = assets["chomp.mp3"];
	chomp.volume( 0.4 );


	//	-	-	-	-	-	-	-	-	-	-	-	-

	// this creates a single bubble sprite
	const mk_bubble = function() {
		let n = rand();
		let img_bubble = assets["bubble.svg"];
		let bubble = new Squid( vec( sw * rand(), sh ), img_bubble );

		bubble.scale = ( 0.2 + n ) * 0.25;
		bubble.opacity = bubble.scale * 5.0;

		bubble.velocity = vec( 0,  -n );

		bubble.draw_priority( toInt( n * 5 ) );

		bubble.listen( "tick", ( delta, tick_num ) => {
			if( bubble.position.y < -10 ) {
				bubble.position = vec( rand() * sw, sh + 20 );
			}
		} );

		return bubble;
	};

	// create a bunch of bubbles for the open ocean
	const NUM_BUBBLES = 25;
	let bubbles = [];
	for( let i = 0 ; i < NUM_BUBBLES ; i++ ) {
		bubbles.push( mk_bubble() );
	}

	// create some bubbles that will come out of the submarine
	const NUM_SUB_BUBBLES = 15;
	let sub_bubbles = [];
	for( let i = 0 ; i < NUM_SUB_BUBBLES ; i++ ) {
		sub_bubbles.push( mk_bubble() );
	}


	//	-	-	-	-	-	-	-	-	-	-	-	-

	// create some fish sprites

	const NUM_FISH_TYPES = 2;
	let school = [];	// holds all the fish
	let vic_num = 0;	// index of victim in school array

	const NUM_FISH = 6;
	for( let i = 0 ; i < NUM_FISH ; i++ ) {

		let type = roll( NUM_FISH_TYPES );
		let img = assets[ "fish"+type+"-lt.png" ];

		// create the fish
		let fish = new Squid( vec( 0, 0 ), img, 0, 1, 0.4 );
		school.push(fish);	// add fish the school

		// Set collision shape.
		// In this case it will be a rectangle that is the same
		// aspect ratio of the fishes image, but a bit smaller.
		fish.hit_shape = vec( img.size() ).mlt( 0.6 );

		// Sets the visual priority to layer #2.
		// There are 5 layers, 1 through 5.
		// Lower numbers appear behind higher numbers.
		fish.draw_priority( 2 );

		// A function that will resets the fish to a new
		// position and swimming direction when it goes
		// offscreen.
		let wrap_fish = function() {
			// default swim from left to right
			fish.position.x = 0;
			fish.velocity = vec( 1.5 + rand(), 0 );
			fish.image = assets["fish"+type+"-rt.png"];
			if( roll( 2 ) ) {	// 50% of the time ...
				// change to swim right to left
				fish.position.x = sw - 1;
				fish.velocity = vec( -1.5 + rand(), 0 );
				fish.image = assets["fish"+type+"-lt.png"];
			}
			// random y position
			fish.position.y = sh * rand();
			vic_num = roll( school.length );	// pick new victim for frank
		}
		wrap_fish();

		// Set up a 'tick' handler for the fish.
		fish.listen( "tick", ( delta, tick_num ) => {
			let px = fish.position.x;
			// if the fish has hit the left or right side of screen,
			// reset it.
			if( px < 0 || px > sw ) {
				wrap_fish();
			}
		} );

		// listen for 'collide' events.
		fish.listen( "collide", ( collider, self ) => {
			if( collider === frank ) {
				// got gobbled up by squid
				if( ! chomp.playing() ) {
					chomp.play();	// play sound effect
				}
				wrap_fish();	// reset fish
			}
		});
	}


	//	-	-	-	-	-	-	-	-	-	-	-	-

	// Frank is a purple squid - isn't he beautiful?

	let img_squid = assets["squid.png"];
	let frank = new Squid( vec( sw / 2, sh ), img_squid, 0, 1.0, 0.30 );

	// make an animation for frank
	const swim_anim = new Anim( 
		[  2, 4, 3, 2, 1, 0 ].map( n => {
			return assets[ "squid_"+n+".svg" ];
		} ), 15, false, false );
	frank.anim = swim_anim;	

	let resting = 100;		// resting between thrusts
	let inking = 0;			// if > 0, then deploy ink

	// Frank's hit shape will be a circle that approximates his image size
	frank.hit_shape = img_squid.make_radius() * 0.45;

	// Choose frank's first victim fish
	vic_num = roll( school.length );

	// Set visual priority
	frank.draw_priority( 2 );

	// Listen for the tick event.
	frank.listen( "tick", ( delta, tick_num ) => {

		// type CTRL-` to turn on debug mode so you can see these messages
		dbg_msgs[2] = "frank spd/hdng/resting : "+rndhun(frank.velocity.length())+" "+rndhun(frank.rotation)+" "+rndhun(resting);
		dbg_msgs[5] = "vic_num "+vic_num;

		let f = school[ vic_num ];	// f is the fish object
		frank.rotate_to( f );		// point frank at the fish

		// if Frank's speed is high, rest for a bit
		if( frank.velocity.length() > 3 ) {
			resting = 50 + toInt( rand() * 150 );
		}

		// Count down the resting number
		if( resting > 0 ) {
			resting--;
			if( resting == 10 ) {		// if resting is almost over ...
				// start animation playing a little before he
				// actually starts thrusting cause it looks more like
				// he's winding up for it.
				frank.anim.play();
			}
			if( resting == 0 ) {			// if resting is over ...
				sploo.play();				// play the thrusting sound
			}
			frank.velocity.mlt( 0.985 );	// and thrust!
		} else {
			frank.thrust( -0.10 );			// slow down cuz, you know ... water
		}

		// Count down the inking number
		if( inking > 0 ) {
			inking -= 1;
			// spew ink every 20 ticks 
			if( inking % 20 == 0 ) {
				ink();
			}
		}

	} );


	// Both frank and fish MUST listen for "collide" for a hit
	// to be detected between the two.
	frank.listen( "collide" );


	// Ink blots

	const NUM_BLOTS = 8;
	const BLOT_LIFESPAN = 300;

	// Ink blot constructor
	function Blot( pos ) {
		let blot = new Squid( pos, assets[ "blot.png" ] );
		let alive = 0;
		blot.live = function() {
			alive = BLOT_LIFESPAN;
			blot.die = function() {
				alive = 0;
				blot.ignore( "tick" );
				blot.ignore( "draw_3" );
			}
			blot.listen( "tick", ( delta, tick_num ) => {

				blot.opacity = alive / BLOT_LIFESPAN;
				blot.scale = alive / BLOT_LIFESPAN;

				alive -= 1;
				if( alive <= 0 ) {
					blot.die();
				}
			} );
			blot.draw_priority( 3 );
			blot.position = vec( frank.position );
		};
		return blot;
	}

	// Create an array of ink blots
	// NOTE:
	// 		Creating a fixed set of squids up front and then just
	// 		reusing them as needed is a technique that is faster
	// 		then constantly recreating objects and it also reduces
	// 		the risk of overconsuming memory/resources.
	let blots = [];
	for( let i = 0 ; i < NUM_BLOTS ; i++ ) {
		blots[ i ] = new Blot();
	}

	// when this is called, one of the precreated ink blots will
	// be made visible via it's live() function
	ink = function() {
		// make an ink blot
		let b = blots.shift();	// pull the one off front of array
		b.live();				// resurrect it
		blots.push( b );		// push to end of array
		sploo.play();			// play the thrusting sound
	};


	//	-	-	-	-	-	-	-	-	-	-	-	-

	// A little submarine that you can control

	let img_sub1 = assets[ "sub1.png" ];
	let img_sub2 = assets[ "sub2.png" ];
	let sub = new Squid( vec( sw / 2, sh / 2 ), img_sub1, 0, 1.0, 0.10 );
	sub.draw_priority( 2 );
	let bubble_num = 0;
	let sub_facing = 1;		// the direction sub is facing; 1 = right, -1 - left
	sub.listen( "tick", ( delta, tick_num ) => {

		// take note of current key status
		let w = keys[ 'w' ];
		let a = keys[ 'a' ];
		let s = keys[ 's' ];
		let d = keys[ 'd' ];

		// set the facing direction
		sub_facing = a ? -1 : d ? 1 : 0;

		// set the image that corresponds with facing
		sub.image = sub_facing == 1 ? img_sub1 : sub_facing == -1 ? img_sub2 : sub.image;

		// modifying rotation
		sub.rotation = a ? 0.1 : d ? -0.1 : 0;
		sub.rotation *= w ? 3 : s ? -3 : 1;

		// set velocity
		sub.velocity.x = a ? -1 : d ? 1 : sub.velocity.x;
		sub.velocity.y = w ? -1 : s ? 1 : (a || d ) ? -0.1 : sub.velocity.y;

		// if velocity is very small, set it to 0
		if( sub.velocity.length() < 0.1 ) {
			sub.velocity.y = 0.1;
		}

		// maybe apply some drag
		sub.velocity.x *= ( a || d ) ? 1 : 0.99;
		sub.velocity.y *= 0.96;

		// if no keys pressed, sink slowly
		if( ! (a || d || w || s ) ) {
			if( abs( sub.velocity.y ) < 0.1 ) {
				sub.velocity.y = 0.1;
			}
		}

		// if sub hits bottom of screen, stop there.
		if( sub.position.y > sh ) {
			sub.position.y = sh;
		}

		// if going left or right, make bubbles
		if( tick_num % 6 == 0 && ( a || d ) ) {
			let bubble = sub_bubbles[ bubble_num ];
			bubble_num += 1;
			if( bubble_num >= sub_bubbles.length ) {
				bubble_num = 0;		// wrap back to 0
			}
			if( bubble ) {
				// move the bubble to the sub's position
				bubble.position.x = sub.position.x - ( ( img_sub1.w * sub.scale * 0.5 ) * sub_facing );
				bubble.position.y = sub.position.y;
			}
		}

	} );


	//	-	-	-	-	-	-	-	-	-	-	-	-

	// Tiler
	//
	// TODO Make this into a Squids module
	// 
	// Squids doesn't have anything to support tile maps built into it.
	// This should probably be in an extension/add-on or something.
	// Anyway, this is one way to do tiles.

	let tile_set = assets[ "tiles.png" ];
	tile_set.smoothing = false;	// turn off smoothing for tiles or it will create artifacts
	const TILE_SIZE = 32;
	const TILESET_WIDTH = toInt( tile_set.w / TILE_SIZE );
	const TILESET_HEIGHT = toInt( tile_set.h / TILE_SIZE );

	// This converts our ascii char from out simplistic tile maps below, into
	// an object with the info needed to draw the appropriate image at the 
	// appropriate place for that tile.
	let tile_cvt = ( row, y ) => {
		return row.split("").map( ( ch, x ) => {

			let t = 15;
			switch( ch ) {
			case " ": t = 0; break;
			case "#": t = 1; break;
			case "=": t = 4; break;
			case ":": t = 8; break;
			case "$": t = 12; break;
			case "v": t = 13; break;
			}

			// precompute src x,y and dest xy for each tile in the map so it doesn't
			// have to be done at render time.
			let sx = toInt( t % TILESET_WIDTH ) * TILE_SIZE
			let sy = toInt( t / TILESET_HEIGHT ) * TILE_SIZE
			let dx = x * TILE_SIZE;
			let dy = y * TILE_SIZE;
			let o = { t, sx, sy, dx, dy };

			return o;
		} );
	};

	let map = [
		"                        =              ",
		"         :              :              ",
		"      ====      v       :             ",
		"      :  :      # v    ::    ###v  =   ",
		" =  $#:v :## = ####    ::  $ ########v ",
		" = #################$= ### $########## ",
	];

	let farmap = [
		"                 $                   $ ",
		"                 $  $===    $        $ ",
		"      ===   $    $  $: :    $  $     $ ",
		"      : :   $    $  $###    $  $   $ $ ",
		"    $ : :v$ $    $  $: :  $ $  $   $ $ ",
		" $ $$ ###$$ $ $  $v $: :$v$$$$ $$  $ $ ",
	];

	let tiles = map.map( tile_cvt );
	let fartiles = farmap.map( tile_cvt );

	const MAP_ROWS = tiles.length;
	const MAP_COLS = tiles[ 0 ].length;
	const TILE_ORIGIN_X = 0;
	const TILE_ORIGIN_Y = sh - ( MAP_ROWS * TILE_SIZE );
	let scr_px = 0;
	let tiler = new Thing();
	const tpx = TILE_SIZE * 0.5;
	const tpy = TILE_SIZE * 0.5;
	const draw_tiles = function( tmap, orig_x, orig_y, opa ) {
		for( let y = 0; y < tmap.length; y++ ) {
			let row = tmap[ y ];
			for( let x = 0 ; x < row.length ; x++ ) {
				let { t, sx, sy, dx, dy } = row[ x ];
				let ddx = orig_x + dx;
				let ddy = orig_y + dy;
				draw_image( tile_set, ddx, ddy, opa, 0, tpx, tpy, 1, 1, sx, sy, TILE_SIZE, TILE_SIZE );
			}
		}
	};
	tiler.listen( "draw_1", () => {
		let ox = TILE_ORIGIN_X - ( sw * 0.25 ) + ( scr_px * 0.4 );
		let oy = TILE_ORIGIN_Y + ( TILE_SIZE * 0.4 );
		draw_tiles( fartiles, ox, oy, 0.25 );
	} );
	tiler.listen( "draw_2", () => {
		let ox = TILE_ORIGIN_X + scr_px;
		let oy = TILE_ORIGIN_Y;
		draw_tiles( tiles, ox, oy, 1.0 );
	} );
	tiler.listen( "tick", () => {
		let xpos = ( frank.position.x - ( sw * 0.5 ) ) / sw;
		if( abs( scr_px - xpos ) <= ( sw * 0.3 ) ) {
			scr_px -= xpos ;
		}
	} );


	//	-	-	-	-	-	-	-	-	-	-	-	-

	// Make an all-seeing overlord (more like a low level administrator)
	// that can do some stuff that's not related to any of the in game 
	// elements, like squids, fish, bubbles, etc.

	let god = new Thing();		// the all-seeing overlord 

	god.listen( "tick", ( delta, num ) => {
		dbg_msgs[ 1 ] = "TICK "+num+" "+delta;
	} );

	god.listen( "draw_0", () => {
		// draw_0 is emitted first, so clear our background here
		// everything else will be drawn afterward and appear in front of
		// the background.
		fill_rect( 0, 0, sw, sh, "#024");	// draw blue bg
	} );

	// listen for key events
	god.listen( "keydown", function( k ) {
		if( k == 'm' ) {
			music.volume( 0 );	// turn off the music
		}
	})

	// listen for mouse events
	god.listen( "mousedown", function( x, y ) {
		if( collide_pos_squid( vec( x, y ), frank ) ) {
			// clicked on the squid, so squirt some ink
			inking = 100;
		}
	})
}

